package com.example.models;

public class CardPayment implements PaymentStrategy {
    @Override
    public boolean processPayment(String cardNumber, double amount) {
        // Mock implementation: process card payment
        System.out.println("Processing card payment for " + amount + " using card " + cardNumber);
        return true; // Assume payment is successful
    }
}

