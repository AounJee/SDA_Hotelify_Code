package com.example.models;

public class Guest extends User {


    public Guest(int id, String username, String password, String role, String contactInfo, String address, String email,String name) {
        super(id, username, password, role,email,name,contactInfo,address);
    }

    // Getters and Setters for Guest-specific attributes
}
