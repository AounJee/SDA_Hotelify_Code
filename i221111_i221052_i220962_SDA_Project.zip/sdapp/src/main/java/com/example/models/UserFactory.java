package com.example.models;

public class UserFactory {

    public static User createUser(int id,String username,String password,String email,String name,String address,String contactInfo,String role) {
        switch (role) {
            case "Guest":
                return new Guest(id, username, password, role, contactInfo, address, email,name);
            case "Employee":
                return new Employee(id, username, password, role, contactInfo, address, email,name);
            case "Admin":
                return new Admin(id, username, password, role, contactInfo, address, email,name);
            default:
                throw new IllegalArgumentException("Invalid role: " + role);
        }
    }
}
