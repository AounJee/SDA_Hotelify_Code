package com.example.models;

public class TimeSlot {
    private int slotId;
    private String startTime; // Format: "HH:mm"
    private String endTime;   // Format: "HH:mm"
    private boolean isAvailable;

    public TimeSlot(int slotId, String startTime, String endTime, boolean isAvailable) {
        this.slotId = slotId;
        this.startTime = startTime;
        this.endTime = endTime;
        this.isAvailable = isAvailable;
    }

    public int getSlotId() {
        return slotId;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public String getTimeRange() {
        return startTime + " - " + endTime;
    }

    public String getAvailabilityString() {
        return isAvailable ? "Available" : "Not Available";
    }
}
