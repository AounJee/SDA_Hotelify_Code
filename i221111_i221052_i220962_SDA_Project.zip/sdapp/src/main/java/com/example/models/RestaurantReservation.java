package com.example.models;

import java.util.Date;

public class RestaurantReservation extends Reservation {
    private int restaurantId;
    private int tableId;
    private int timeSlotId;

    public RestaurantReservation(int reservationId,int userId,int restaurantId,int tableId,int timeSlotId, Date startDate, Date endDate) {
        super(reservationId, userId, startDate, endDate);
        this.restaurantId = restaurantId;
        this.tableId = tableId;
        this.timeSlotId = timeSlotId;
    }

    @Override
    public String getReservationType() {
        return "RestaurantReservation";
    }

    @Override
    public int getRoomID() {
        return 0;
    }

    @Override
    public int getTableID() {
        return tableId;
    }

    @Override
    public int getTimeSlotID() {
        return timeSlotId;
    }

    @Override
    public int getHallID() {
        return 0;
    }

    @Override
    public int getRestaurantID() {
        return restaurantId;
    }

    public int getTableId() {
        return tableId;
    }

    public int getRestaurantId() {
        return restaurantId;
    }

    public int getTimeSlotId() {
        return timeSlotId;
    }
}
