package com.example.models;

import java.util.Date;

public class RoomReservation extends Reservation {
    private int roomId;

    public RoomReservation(int reservationId,int userId,int roomId, Date startDate, Date endDate) {
        super(reservationId, userId, startDate, endDate);
        this.roomId = roomId;
    }

    @Override
    public String getReservationType() {
        return "RoomReservation";
    }

    @Override
    public int getRoomID() {
        return roomId;
    }

    @Override
    public int getTableID() {
        return 0;
    }

    @Override
    public int getTimeSlotID() {
        return 0;
    }

    @Override
    public int getHallID() {
        return 0;
    }

    @Override
    public int getRestaurantID() {
        return 0;
    }

    public int getRoomId() {
        return roomId;
    }
}
