package com.example.models;

import java.util.List;

public class Table {
    private int tableId;
    private List<TimeSlot> timeSlots;

    public Table(int tableId, List<TimeSlot> timeSlots) {
        this.tableId = tableId;
        this.timeSlots = timeSlots;
    }

    public int getTableId() {
        return tableId;
    }

    public List<TimeSlot> getTimeSlots() {
        return timeSlots;
    }
}
