package com.example.models;

public class Room {
    private int roomId;
    private int floor;
    private int price;
    private String type; // Single, Double, Suite
    private boolean isAvailable;

    public Room(int roomId,int floor,int price, String type, boolean isAvailable) {
        this.roomId = roomId;
        this.floor = floor;
        this.price = price;
        this.type = type;
        this.isAvailable = isAvailable;
    }

    public int getRoomId() {
        return roomId;
    }

    public String getType() {
        return type;
    }

    public int getPrice() {
        return price;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }
}

