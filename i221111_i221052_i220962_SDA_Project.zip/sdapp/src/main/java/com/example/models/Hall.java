package com.example.models;

import java.util.List;

public class Hall {
    private int hallId;
    private int capacity;
    private int price;
    private List<TimeSlot> timeSlots;

    public Hall(int hallId,int price, int capacity, List<TimeSlot> timeSlots) {
        this.hallId = hallId;
        this.price = price;
        this.capacity = capacity;
        this.timeSlots = timeSlots;
    }

    public int getHallId() {
        return hallId;
    }

    public int getCapacity() {
        return capacity;
    }

    public List<TimeSlot> getTimeSlots() {
        return timeSlots;
    }

    public void setTimeSlots(List<TimeSlot> timeSlots) {
        this.timeSlots = timeSlots;
    }
}
