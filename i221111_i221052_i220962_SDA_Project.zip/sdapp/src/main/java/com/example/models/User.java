package com.example.models;

public abstract class User {
    private int userID;
    private String username;
    private String password;
    private String role;
    private String name;
    private String email;
    private String contactInfo;
    private String address;

    public User(int id, String username, String password, String role, String email, String name,String contactInfo,String address) {
        this.userID = id;
        this.username = username;
        this.password = password;
        this.role = role;
        this.email = email;
        this.name = name;
        this.contactInfo = contactInfo;
        this.address = address;
    }

    // Getters and Setters
    public int getUserID() { return userID; }
    public void setUserID(int userID) { this.userID = userID; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getcontactInfo() {
        return contactInfo;
    }

    public String getAddress() {
        return address;
    }

    public void setName(String text) {
        this.name = text;
    }

    public void setEmail(String text) {
        this.email = text;
    }

    public void setContactInfo(String text) {
        this.contactInfo = text;
    }

    public void setAddress(String text) {
        this.address = text;
    }
}
