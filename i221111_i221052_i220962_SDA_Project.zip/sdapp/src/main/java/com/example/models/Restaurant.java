package com.example.models;

import java.util.List;

public class Restaurant {
    private int restaurantId;
    private List<Table> tables;
    private int capacity;

    public Restaurant(int restaurantId, int capacity, List<Table> tables) {
        this.restaurantId = restaurantId;
        this.capacity = capacity;
        this.tables = tables;
    }

    public List<Table> getTables() {
        return tables;
    }

    public void setTables(List<Table> tables) {
        this.tables = tables;
    }

    public int getCapacity() {
        return capacity;
    }
}
