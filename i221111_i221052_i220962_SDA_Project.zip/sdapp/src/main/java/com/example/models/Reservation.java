package com.example.models;

import java.util.Date;

public abstract class Reservation {
    private int reservationId;
    private int userId;
    private Date startDate;
    private Date endDate;


    public Reservation(int reservationId,int userId, Date startDate, Date endDate) {
        this.reservationId = reservationId;
        this.userId = userId;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public int getReservationId() {
        return reservationId;
    }

    public int getUserId() {
        return userId;
    }

    public abstract String getReservationType();
    public abstract int getRoomID();
    public abstract int getTableID();
    public abstract int getTimeSlotID();
    public abstract int getHallID();
    public abstract int getRestaurantID();

    public Date getStartDate() {
        return startDate;
    }

    public Date getEndDate() {
        return endDate;
    }
}

