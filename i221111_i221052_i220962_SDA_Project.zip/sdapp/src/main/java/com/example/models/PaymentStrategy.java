package com.example.models;

public interface PaymentStrategy {
    boolean processPayment(String accountNumber, double amount);
}

