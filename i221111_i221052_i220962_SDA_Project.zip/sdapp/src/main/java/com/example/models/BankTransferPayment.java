package com.example.models;

public class BankTransferPayment implements PaymentStrategy {
    @Override
    public boolean processPayment(String accountNumber, double amount) {
        // Mock implementation: process bank transfer
        System.out.println("Processing bank transfer for " + amount + " using account " + accountNumber);
        return true; // Assume payment is successful
    }
}
