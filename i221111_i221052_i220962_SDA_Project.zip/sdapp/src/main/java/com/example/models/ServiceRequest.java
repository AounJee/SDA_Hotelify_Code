package com.example.models;

public class ServiceRequest {
    private int serviceId;
    private int roomId;
    private String status;

    public ServiceRequest(int serviceId, int roomId, String status) {
        this.serviceId = serviceId;
        this.roomId = roomId;
        this.status = status;
    }

    public int getServiceId() {
        return serviceId;
    }

    public int getRoomId() {
        return roomId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
