package com.example.models;

public class Employee extends User {


    public Employee(int id, String username, String password, String role, String contactInfo, String address, String email,String name) {
        super(id, username, password, role,email,name,contactInfo,address);
    }

    // Getters and Setters for Employee-specific attributes
}
