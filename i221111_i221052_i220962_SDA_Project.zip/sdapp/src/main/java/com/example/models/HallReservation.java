package com.example.models;

import java.util.Date;

public class HallReservation extends Reservation {
    private int hallId;
    private int timeSlotId;

    public HallReservation(int reservationId,int userId,int hallId,int timeSlotId, Date startDate, Date endDate) {
        super(reservationId, userId, startDate, endDate);
        this.hallId = hallId;
        this.timeSlotId = timeSlotId;
    }


    @Override
    public String getReservationType() {
        return "HallReservation";
    }

    @Override
    public int getRoomID() {
        return 0;
    }

    @Override
    public int getTableID() {
        return 0;
    }

    @Override
    public int getTimeSlotID() {
        return timeSlotId;
    }

    @Override
    public int getHallID() {
        return hallId;
    }

    @Override
    public int getRestaurantID() {
        return 0;
    }

    public int getHallId() {
        return hallId;
    }

    public int getTimeSlotId() {
        return timeSlotId;
    }
}
