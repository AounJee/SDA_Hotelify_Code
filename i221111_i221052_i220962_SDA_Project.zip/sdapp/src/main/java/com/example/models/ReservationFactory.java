package com.example.models;

import java.util.Date;

public class ReservationFactory {

    /**
     * Creates a Reservation object based on the reservation type.
     *
     * @param reservationId The reservation ID.
     * @param userId        The user ID.
     * @param type          The type of reservation (RoomReservation, RestaurantReservation, HallReservation).
     * @param roomId        The room ID (if applicable).
     * @param restaurantId  The restaurant ID (if applicable).
     * @param tableId       The table ID (if applicable).
     * @param hallId        The hall ID (if applicable).
     * @param timeSlotId    The time slot ID (if applicable).
     * @param startDate     The reservation start date.
     * @param endDate       The reservation end date.
     * @return The appropriate Reservation object.
     */
    public static Reservation createReservation(
            int reservationId,
            int userId,
            String type,
            Integer roomId,
            Integer restaurantId,
            Integer tableId,
            Integer hallId,
            Integer timeSlotId,
            Date startDate,
            Date endDate
    ) {
        switch (type) {
            case "RoomReservation":
                if (roomId == null) {
                    throw new IllegalArgumentException("Room ID is required for RoomReservation");
                }
                return new RoomReservation(reservationId, userId, roomId, startDate, endDate);

            case "RestaurantReservation":
                if (restaurantId == null || tableId == null || timeSlotId == null) {
                    throw new IllegalArgumentException("Restaurant ID, Table ID, and Time Slot ID are required for RestaurantReservation");
                }
                return new RestaurantReservation(reservationId, userId, restaurantId, tableId, timeSlotId, startDate, endDate);

            case "HallReservation":
                if (hallId == null || timeSlotId == null) {
                    throw new IllegalArgumentException("Hall ID and Time Slot ID are required for HallReservation");
                }
                return new HallReservation(reservationId, userId, hallId, timeSlotId, startDate, endDate);

            default:
                throw new IllegalArgumentException("Unknown reservation type: " + type);
        }
    }
}
