package com.example.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBHandler {
    private static DBHandler instance;
    private Connection connection;

    private DBHandler() {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/hotelify", "root", "abcd");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static DBHandler getInstance() {
        if (instance == null) {
            synchronized (DBHandler.class) {
                if (instance == null) {
                    instance = new DBHandler();
                }
            }
        }
        return instance;
    }

    public Connection getConnection() {
        return connection;
    }
}
