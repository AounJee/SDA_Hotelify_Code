package com.example.dao;

import com.example.db.DBHandler;
import com.example.models.ServiceRequest;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ServiceRequestDAO {
    private final Connection connection;

    public ServiceRequestDAO() {
        this.connection = DBHandler.getInstance().getConnection();
    }

    /**
     * Fetches all pending room service requests.
     *
     * @return A list of pending room service requests.
     * @throws SQLException If a database error occurs.
     */
    public List<ServiceRequest> getAllPendingRequests() throws SQLException {
        String sql = "SELECT * FROM service_requests WHERE status = 'Pending'";
        List<ServiceRequest> requests = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                int roomId = rs.getInt("room_id");
                String status = rs.getString("status");
                requests.add(new ServiceRequest(id, roomId, status));
            }
        }

        return requests;
    }

    /**
     * Resolves a room service request by updating its status to 'Resolved'.
     *
     * @param requestId The ID of the request to resolve.
     * @return true if the update was successful; false otherwise.
     * @throws SQLException If a database error occurs.
     */
    public boolean resolveRequest(int requestId) throws SQLException {
        String sql = "UPDATE service_requests SET status = 'Resolved' WHERE id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, requestId);
            return stmt.executeUpdate() > 0;
        }
    }
}
