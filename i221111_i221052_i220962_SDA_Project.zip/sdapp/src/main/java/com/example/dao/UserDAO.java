package com.example.dao;

import com.example.db.DBHandler;
import com.example.models.UserFactory;
import com.example.models.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    private final Connection connection;

    public UserDAO() {
        this.connection = DBHandler.getInstance().getConnection();
    }

    // Insert a new user into the Hotel_User table
    public boolean addUser(User user) throws SQLException {
        String sql = "INSERT INTO Hotel_User (Username, User_Password, Role) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getRole());
            return stmt.executeUpdate() > 0;
        }
    }

    // Retrieve all users from the Hotel_User table
    public List<User> getAllUsers() throws SQLException {
        String sql = "SELECT * FROM Hotel_User";
        List<User> users = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int userID = rs.getInt("UserID");
                String username = rs.getString("Username");
                String password = rs.getString("User_Password");
                String role = rs.getString("Role");
                String email = rs.getString("Email");
                String contactinfo = rs.getString("ContactInfo");
                String address = rs.getString("Address");
                String name = rs.getString("User_Name");

                // Use UserFactory to create the correct type of User
                users.add(UserFactory.createUser(userID, username, password,email,name,address,contactinfo,role));
            }
        }
        return users;
    }

    // Update user information in the Hotel_User table
    public boolean updateUser(User user) throws SQLException {
        String sql = "UPDATE Hotel_User SET Username = ?, User_Password = ?, Role = ? WHERE UserID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getPassword());
            stmt.setString(3, user.getRole());
            stmt.setInt(4, user.getUserID());
            return stmt.executeUpdate() > 0;
        }
    }

    // Delete a user from the Hotel_User table by UserID
    public boolean deleteUser(int userID) throws SQLException {
        String sql = "DELETE FROM Hotel_User WHERE UserID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, userID);
            return stmt.executeUpdate() > 0;
        }
    }

    // Verify user login credentials (Username and Password)
    public boolean verifyLogin(String username, String password) throws SQLException {
        String sql = "SELECT 1 FROM Hotel_User WHERE Username = ? AND User_Password = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next(); // If there is a result, the login is valid
            }
        }
    }
}
