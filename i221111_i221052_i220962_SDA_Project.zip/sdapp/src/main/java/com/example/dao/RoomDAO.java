package com.example.dao;

import com.example.db.DBHandler;
import com.example.models.Room;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RoomDAO {
    private final Connection connection;

    public RoomDAO() {
        this.connection = DBHandler.getInstance().getConnection();
    }

    public boolean addRoom(Room room) throws SQLException {
        String sql = "INSERT INTO Room (RoomID, RoomType, AvailabilityStatus) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, room.getRoomId());
            stmt.setString(2, room.getType());
            stmt.setBoolean(3, room.isAvailable());
            return stmt.executeUpdate() > 0;
        }
    }

    public List<Room> getAllRooms() throws SQLException {
        String sql = "SELECT * FROM Room";
        List<Room> rooms = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("RoomID");
                int floor = rs.getInt("FloorNumber");
                int price = rs.getInt("PricePerHour");
                String type = rs.getString("RoomType");
                boolean isAvailable = rs.getString("AvailabilityStatus") == "Available";
                rooms.add(new Room(id,floor,price,type,isAvailable));
            }
        }
        return rooms;
    }

    public boolean updateRoom(Room room) throws SQLException {
        String sql = "UPDATE Room SET RoomType = ?, AvailabilityStatus = ? WHERE RoomID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, room.getType());
            stmt.setBoolean(2, room.isAvailable());
            stmt.setInt(3, room.getRoomId());
            return stmt.executeUpdate() > 0;
        }
    }

    public boolean deleteRoom(int roomId) throws SQLException {
        String sql = "DELETE FROM Room WHERE RoomID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, roomId);
            return stmt.executeUpdate() > 0;
        }
    }

    public boolean bookRoom(int roomId) throws SQLException {
        String sql = "UPDATE Room SET AvailabilityStatus = FALSE WHERE RoomID = ? AND AvailabilityStatus = TRUE";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, roomId);
            return stmt.executeUpdate() > 0;
        }
    }

    public double getRoomPrice(int roomId) throws SQLException {
        String sql = "SELECT PricePerHour FROM Room WHERE RoomID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, roomId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("PricePerHour");
                }
            }
        }
        return 0.0;
    }


    public List<Room> getAllAvailableRooms() throws SQLException {
        String sql = "SELECT * FROM Room WHERE AvailabilityStatus = TRUE";
        List<Room> rooms = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("RoomID");
                int floor = rs.getInt("FloorNumber");
                int price = rs.getInt("PricePerHour");
                String type = rs.getString("RoomType");
                boolean isAvailable = rs.getBoolean("AvailabilityStatus");
                rooms.add(new Room(id,floor,price,type,isAvailable));
            }
        }

        return rooms;
    }
}
