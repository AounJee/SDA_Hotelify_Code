package com.example.dao;

import com.example.db.DBHandler;
import com.example.models.Restaurant;
import com.example.models.Table;
import com.example.models.TimeSlot;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RestaurantDAO {
    private final Connection connection;

    public RestaurantDAO() {
        this.connection = DBHandler.getInstance().getConnection();
    }

    /**
     * Retrieves all restaurant tables along with their associated time slots.
     *
     * @return A Restaurant object containing tables and their time slots.
     * @throws SQLException If a database error occurs.
     */
    public Restaurant getRestaurant() throws SQLException {
        String sql = "SELECT RestaurantID, capacity FROM Restaurant";
        String tableSql = "SELECT TableID FROM Restaurant_Table";
        String slotSql = "SELECT * FROM TimeSlot WHERE TableID = ?";

        Restaurant restaurant = null;

        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                int restaurantId = rs.getInt("RestaurantID");
                int capacity = rs.getInt("Capacity");

                List<Table> tables = new ArrayList<>();
                try (PreparedStatement tableStmt = connection.prepareStatement(tableSql)) {
                    ResultSet tableRs = tableStmt.executeQuery();

                    while (tableRs.next()) {
                        int tableId = tableRs.getInt("TableID");
                        List<TimeSlot> timeSlots = new ArrayList<>();

                        try (PreparedStatement slotStmt = connection.prepareStatement(slotSql)) {
                            slotStmt.setInt(1, tableId);
                            ResultSet slotRs = slotStmt.executeQuery();

                            while (slotRs.next()) {
                                int slotId = slotRs.getInt("SlotID");
                                String startTime = slotRs.getString("StartTime");
                                String endTime = slotRs.getString("EndTime");
                                boolean isAvailable = slotRs.getString("AvailabilityStatus") == "Available";
                                timeSlots.add(new TimeSlot(slotId, startTime, endTime, isAvailable));
                            }
                        }

                        tables.add(new Table(tableId, timeSlots));
                    }
                }

                restaurant = new Restaurant(restaurantId, capacity, tables);
            }
        }

        return restaurant;
    }

    /**
     * Books a time slot for a specific table.
     *
     * @param slotId The ID of the time slot to book.
     * @return true if booking is successful, false otherwise.
     * @throws SQLException If a database error occurs.
     */
    public boolean bookTimeSlot(int slotId) throws SQLException {
        String sql = "UPDATE TimeSlot SET is_available = FALSE WHERE SlotID = ? AND AvailabilityStatus = TRUE";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, slotId);
            return stmt.executeUpdate() > 0;
        }
    }
}
