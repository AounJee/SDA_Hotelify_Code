package com.example.dao;

import com.example.db.DBHandler;
import com.example.models.Reservation;
import com.example.models.RoomReservation;
import com.example.models.RestaurantReservation;
import com.example.models.HallReservation;
import com.example.models.ReservationFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ReservationDAO {
    private final Connection connection;

    public ReservationDAO() {
        this.connection = DBHandler.getInstance().getConnection();
    }

    /**
     * Adds a new reservation to the database.
     *
     * @param reservation The reservation object.
     * @return true if the reservation is added successfully, false otherwise.
     * @throws SQLException If a database error occurs.
     */
    public boolean addReservation(Reservation reservation) throws SQLException {
        String sql = "";

        if (reservation.getReservationType().equals("RoomReservation")) {
            sql += "INSERT INTO reservations (UserID, RoomID, EndDate, StartDate, Reservation_Status) " +
                    "VALUES (?, ?, ?, ?, ?)";
        } else if (reservation.getReservationType().equals("RestaurantReservation")) {
            sql += "INSERT INTO RestaurantReservation (UserID,TableID ,TimeslotID) " +
                    "VALUES (?, ?, ?)";
        } else if (reservation.getReservationType().equals("HallReservation")) {
            sql += "INSERT INTO HallReservation (UserID,HallID,TimeslotID,EventDate,HallReservationStatus)" +
                    "VALUES (?, ?, ?, ?, ?)";
        }


        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, reservation.getUserId());

            if (reservation.getReservationType().equals("RoomReservation")) {
                stmt.setInt(2, reservation.getRoomID());
                stmt.setDate(3, new java.sql.Date(reservation.getStartDate().getTime()));
                stmt.setDate(4, new java.sql.Date(reservation.getEndDate().getTime()));
                stmt.setString(5, "active" );
            } else if (reservation.getReservationType().equals("RestaurantReservation")) {
                stmt.setInt(2, reservation.getTableID());
                stmt.setInt(3, reservation.getTimeSlotID());
            } else if (reservation.getReservationType().equals("HallReservation")) {
                stmt.setInt(2, reservation.getHallID());
                stmt.setInt(3, reservation.getTimeSlotID());
                stmt.setDate(4, new java.sql.Date(reservation.getStartDate().getTime()));
                stmt.setString(5, "active" );
            }

            return stmt.executeUpdate() > 0;
        }
    }

    public List<Reservation> getReservationsByUser(int userId) throws SQLException {
        String sql = "SELECT r.UserID, r.StartDate, r.EndDate, r.RoomID, NULL AS TableID, NULL AS TimeSlotID, NULL AS HallID, NULL AS EventDate, 'RoomReservation' AS Type " +
                "FROM reservations r " +
                "WHERE r.UserID = ? " +
                "UNION ALL " +
                "SELECT rr.UserID, NULL AS StartDate, NULL AS EndDate, NULL AS RoomID, rr.TableID, rr.TimeSlotID, NULL AS HallID, NULL AS EventDate, 'RestaurantReservation' AS Type " +
                "FROM RestaurantReservation rr " +
                "WHERE rr.UserID = ? " +
                "UNION ALL " +
                "SELECT hr.UserID, hr.EventDate AS StartDate, NULL AS EndDate, NULL AS RoomID, NULL AS TableID, hr.TimeSlotID, hr.HallID, hr.EventDate, 'HallReservation' AS Type " +
                "FROM HallReservation hr " +
                "WHERE hr.UserID = ?";

        List<Reservation> reservations = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, userId);
            stmt.setInt(3, userId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String type = rs.getString("Type");
                    int reservationId = rs.getInt("UserID");
                    int userID = rs.getInt("UserID");
                    Date startDate = rs.getDate("StartDate");
                    Date endDate = rs.getDate("EndDate");

                    Integer roomID = rs.getObject("RoomID", Integer.class);
                    Integer tableID = rs.getObject("TableID", Integer.class);
                    Integer timeSlotID = rs.getObject("TimeSlotID", Integer.class);
                    Integer hallID = rs.getObject("HallID", Integer.class);

                    // Use ReservationFactory to create the appropriate type
                    reservations.add(ReservationFactory.createReservation(
                            reservationId,
                            userID,
                            type,
                            roomID,
                            null, // Restaurant ID not applicable here
                            tableID,
                            hallID,
                            timeSlotID,
                            startDate,
                            endDate
                    ));
                }
            }
        }

        return reservations;
    }


    /**
     * Deletes a reservation by ID.
     *
     * @param reservationId The reservation ID.
     * @return true if the deletion is successful, false otherwise.
     * @throws SQLException If a database error occurs.
     */
    public boolean deleteReservation(int reservationId, String reservationType) throws SQLException {
        String sql = "";

        if ("RoomReservation".equals(reservationType)) {
            sql = "DELETE FROM reservations WHERE RoomID = ?";
        } else if ("RestaurantReservation".equals(reservationType)) {
            sql = "DELETE FROM RestaurantReservation WHERE TableID = ?";
        } else if ("HallReservation".equals(reservationType)) {
            sql = "DELETE FROM HallReservation WHERE HallID = ?";
        } else {
            throw new IllegalArgumentException("Invalid reservation type: " + reservationType);
        }

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, reservationId);
            return stmt.executeUpdate() > 0;
        }
    }

}
