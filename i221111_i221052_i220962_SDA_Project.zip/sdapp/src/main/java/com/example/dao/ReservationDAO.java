package com.example.dao;

import com.example.db.DBHandler;
import com.example.models.Reservation;
import com.example.models.RoomReservation;
import com.example.models.RestaurantReservation;
import com.example.models.HallReservation;
import com.example.models.ReservationFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ReservationDAO {
    private final Connection connection;

    public ReservationDAO() {
        this.connection = DBHandler.getInstance().getConnection();
    }

    /**
     * Adds a new reservation to the database.
     *
     * @param reservation The reservation object.
     * @return true if the reservation is added successfully, false otherwise.
     * @throws SQLException If a database error occurs.
     */
    public boolean addReservation(Reservation reservation) throws SQLException {
        String sql = "";

        if (reservation.getReservationType().equals("RoomReservation")) {
            sql += "INSERT INTO reservations (UserID, RoomID, EndDate, StartDate, Reservation_Status) " +
                    "VALUES (?, ?, ?, ?, ?)";
        } else if (reservation.getReservationType().equals("RestaurantReservation")) {
            sql += "INSERT INTO RestaurantReservation (UserID,TableID ,TimeslotID) " +
                    "VALUES (?, ?, ?)";
        } else if (reservation.getReservationType().equals("HallReservation")) {
            sql += "INSERT INTO HallReservation (UserID,HallID,TimeslotID,EventDate,HallReservationStatus)" +
                    "VALUES (?, ?, ?, ?, ?)";
        }


        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, reservation.getUserId());

            if (reservation.getReservationType().equals("RoomReservation")) {
                stmt.setInt(2, reservation.getRoomID());
                stmt.setDate(3, new java.sql.Date(reservation.getStartDate().getTime()));
                stmt.setDate(4, new java.sql.Date(reservation.getEndDate().getTime()));
                stmt.setString(5, "active" );
            } else if (reservation.getReservationType().equals("RestaurantReservation")) {
                stmt.setInt(2, reservation.getTableID());
                stmt.setInt(3, reservation.getTimeSlotID());
            } else if (reservation.getReservationType().equals("HallReservation")) {
                stmt.setInt(2, reservation.getHallID());
                stmt.setInt(3, reservation.getTimeSlotID());
                stmt.setDate(4, new java.sql.Date(reservation.getStartDate().getTime()));
                stmt.setString(5, "active" );
            }

            return stmt.executeUpdate() > 0;
        }
    }

    public List<Reservation> getRoomReservationsByUser(int userId) throws SQLException {
        String sql = "SELECT r.ReservationID,r.UserID, r.StartDate, r.EndDate, r.RoomID " +
                "FROM Reservation r " +
                "WHERE r.UserID = ? ";

        List<Reservation> reservations = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, userId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String type = "RoomReservation";
                    int reservationId = rs.getInt("ReservationID");
                    int userID = rs.getInt("UserID");
                    int roomID = rs.getInt("roomID");
                    Date startDate = rs.getDate("StartDate");
                    Date endDate = rs.getDate("EndDate");

                    // Use ReservationFactory to create the appropriate type
                    reservations.add(ReservationFactory.createReservation(
                            reservationId,
                            userID,
                            type,
                            roomID,
                            0, // Restaurant ID not applicable here
                            0,
                            0,
                            0,
                            startDate,
                            endDate
                    ));
                }
            }
        }

        return reservations;
    }
    public List<Reservation> getRestaurantReservationsByUser(int userId) throws SQLException {
        String sql = "SELECT rr.ReservationID,rr.UserID,rr.TableID, rr.TimeSlotID " +
                "FROM RestaurantReservation rr " +
                "WHERE rr.UserID = ? ";

        List<Reservation> reservations = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, userId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String type = "RestaurantReservation";
                    int reservationId = rs.getInt("ReservationID");
                    int userID = rs.getInt("UserID");
                    int tableID = rs.getInt("tableID");
                    int timeSlotID = rs.getInt("TimeSlotID");

                    // Use ReservationFactory to create the appropriate type
                    reservations.add(ReservationFactory.createReservation(
                            reservationId,
                            userID,
                            type,
                            0,
                            null, // Restaurant ID not applicable here
                            tableID,
                            0,
                            timeSlotID,
                            new Date(),
                            new Date()
                    ));
                }
            }
        }

        return reservations;
    }
    public List<Reservation> getHallReservationsByUser(int userId) throws SQLException {

        String sql = "SELECT hr.ReservationID,hr.UserID, hr.EventDate AS StartDate, hr.TimeSlotID, hr.HallID, hr.EventDate " +
                "FROM HallReservation hr " +
                "WHERE hr.UserID = ?";

        List<Reservation> reservations = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, userId);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String type = "HallReservation";
                    int reservationId = rs.getInt("ReservationID");
                    int userID = rs.getInt("UserID");
                    int tableID = rs.getInt("HallID");
                    int timeSlotID = rs.getInt("TimeSlotID");
                    Date startDate = rs.getDate("StartDate");
                    Date endDate = rs.getDate("EndDate");

                    // Use ReservationFactory to create the appropriate type
                    reservations.add(ReservationFactory.createReservation(
                            reservationId,
                            userID,
                            type,
                            0,
                            null, // Restaurant ID not applicable here
                            tableID,
                            0,
                            timeSlotID,
                            startDate,
                            endDate
                    ));
                }
            }
        }

        return reservations;
    }


    /**
     * Deletes a reservation by ID.
     *
     * @param reservationId The reservation ID.
     * @return true if the deletion is successful, false otherwise.
     * @throws SQLException If a database error occurs.
     */
    public boolean deleteReservation(int reservationId, String reservationType) throws SQLException {
        String sql = "";

        if ("RoomReservation".equals(reservationType)) {
            sql = "DELETE FROM reservations WHERE RoomID = ?";
        } else if ("RestaurantReservation".equals(reservationType)) {
            sql = "DELETE FROM RestaurantReservation WHERE TableID = ?";
        } else if ("HallReservation".equals(reservationType)) {
            sql = "DELETE FROM HallReservation WHERE HallID = ?";
        } else {
            throw new IllegalArgumentException("Invalid reservation type: " + reservationType);
        }

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, reservationId);
            return stmt.executeUpdate() > 0;
        }
    }

}
