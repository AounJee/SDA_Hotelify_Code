package com.example.dao;

import com.example.db.DBHandler;
import com.example.models.Hall;
import com.example.models.TimeSlot;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HallDAO {
    private final Connection connection;

    public HallDAO() {
        this.connection = DBHandler.getInstance().getConnection();
    }

    /**
     * Retrieves all halls and their associated time slots.
     *
     * @return A list of halls with their time slots.
     * @throws SQLException If a database error occurs.
     */
    public List<Hall> getAllHalls() throws SQLException {
        String sql = "SELECT * FROM EventHall";
        List<Hall> halls = new ArrayList<>();
        TimeSlotDAO timeSlotDAO = new TimeSlotDAO();

        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int hallId = rs.getInt("HallID");
                int capacity = rs.getInt("capacity");
                int price = rs.getInt("PricePerHour");
                List<TimeSlot> timeSlots = timeSlotDAO.getTimeSlotsForEntity(hallId);
                halls.add(new Hall(hallId,price, capacity, timeSlots));
            }
        }
        return halls;
    }

    /**
     * Books a specific time slot for a hall.
     *
     * @param slotId The ID of the time slot to book.
     * @return true if booking is successful; false otherwise.
     * @throws SQLException If a database error occurs.
     */
    public boolean bookHallTimeSlot(int slotId) throws SQLException {
        TimeSlotDAO timeSlotDAO = new TimeSlotDAO();
        return timeSlotDAO.bookTimeSlot(slotId);
    }

    public double getHallPrice(int hallId) throws SQLException {
        String sql = "SELECT price FROM EventHall WHERE HallID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, hallId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getDouble("price");
                }
            }
        }
        return 0.0;
    }

}
