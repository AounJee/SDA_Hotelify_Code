package com.example.dao;

import com.example.db.DBHandler;
import com.example.models.TimeSlot;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TimeSlotDAO {
    private final Connection connection;

    public TimeSlotDAO() {
        this.connection = DBHandler.getInstance().getConnection();
    }


    public List<TimeSlot> getTimeSlotsForEntity(int entityId) throws SQLException {
        String sql = "SELECT * FROM TimeSlot WHERE TableID = ?";
        List<TimeSlot> timeSlots = new ArrayList<>();

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, entityId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int slotId = rs.getInt("SlotID");
                String startTime = rs.getString("StartTime");
                String endTime = rs.getString("EndTime");
                boolean isAvailable = rs.getString("AvailabilityStatus")=="Available";
                timeSlots.add(new TimeSlot(slotId, startTime, endTime, isAvailable));
            }
        }

        return timeSlots;
    }

    /**
     * Books a time slot by marking it as unavailable.
     *
     * @param slotId The ID of the time slot to book.
     * @return true if the booking is successful; false otherwise.
     * @throws SQLException If a database error occurs.
     */
    public boolean bookTimeSlot(int slotId) throws SQLException {
        String sql = "UPDATE TimeSlot SET AvailabilityStatus = FALSE WHERE SlotID = ? AND AvailabilityStatus = TRUE";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, slotId);
            return stmt.executeUpdate() > 0;
        }
    }
}
