package com.example.sdapp;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class SceneChanger {
    private final Stage currentStage;

    // Constructor to initialize the stage
    public SceneChanger() {
        this.currentStage = new Stage();
    }

    // Method to change the scene based on the given FXML file path
    public void changeScene(String fxmlPath, String title, int width, int height) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(fxmlPath));
        Scene scene = new Scene(fxmlLoader.load(), width, height);

        // Set the SceneChanger in the loaded controller
        Object controller = fxmlLoader.getController();
        if (controller instanceof WelcomePageController) {
            ((WelcomePageController) controller).setSceneChanger(this);
        } else if (controller instanceof RegisterPageController) {
            ((RegisterPageController) controller).setSceneChanger(this);
        }
        else if (controller instanceof LandingPageController){
            ((LandingPageController) controller).setSceneChanger(this);
        }

        currentStage.setTitle(title);
        currentStage.setScene(scene);
        currentStage.show();
    }
}
