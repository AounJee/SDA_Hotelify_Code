package com.example.sdapp;

import com.example.dao.UserDAO;
import com.example.models.User;
import com.example.models.UserFactory;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.paint.Color;

import java.io.IOException;

public class RegisterPageController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField nameField;

    @FXML
    private TextField addressField;

    @FXML
    private TextField contactInfoField;

    @FXML
    private ChoiceBox<String> userTypeChoice;

    @FXML
    private Button registerButton;

    @FXML
    private Button backButton;

    @FXML
    private Label errorLabel;

    private UserDAO userDAO;
    private SceneChanger sceneChanger;

    public RegisterPageController() {
        // Initialize the UserDAO to handle database operations
        userDAO = new UserDAO();
    }

    @FXML
    public void initialize() {
        // Initialize ChoiceBox with role options
        userTypeChoice.setItems(FXCollections.observableArrayList("Guest", "Employee"));
    }

    @FXML
    private void onRegisterPressed() throws IOException {

        //sceneChanger.changeScene("landing-page.fxml","Hotelify - Dashboard !",1200,600);

        // Clear any previous error messages
        errorLabel.setText("");
        errorLabel.setTextFill(Color.RED);

        // Retrieve input from the form
        String username = usernameField.getText();
        String password = passwordField.getText();
        String email = emailField.getText();
        String name = nameField.getText();
        String address = addressField.getText();
        String contactInfo = contactInfoField.getText();
        String role = userTypeChoice.getValue();

        // Input validation
        if (username.isEmpty() || password.isEmpty() || email.isEmpty() || name.isEmpty() ||
                address.isEmpty() || contactInfo.isEmpty() || role == null) {
            errorLabel.setText("All fields are required!");
            return;
        }

        try {
            // Use the UserFactory to create the appropriate User object
            User newUser = UserFactory.createUser(0,username, password, email, name, address, contactInfo, role);

            // Attempt to add the user to the database
            boolean success = userDAO.addUser(newUser);

            if (success) {
                // Clear the form and show success message
                clearForm();
                errorLabel.setTextFill(Color.GREEN);
                errorLabel.setText("Registration successful!");

                onBackPressed();

            } else {
                errorLabel.setText("Failed to register user. Please try again.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            errorLabel.setText("An error occurred: " + e.getMessage());
        }
    }

    @FXML
    private void onBackPressed() throws IOException {
        sceneChanger.changeScene("hello-view.fxml","Hotelify - Welcome !",600,400);
    }

    // Helper method to clear the form after successful registration
    private void clearForm() {
        usernameField.clear();
        passwordField.clear();
        emailField.clear();
        nameField.clear();
        addressField.clear();
        contactInfoField.clear();
        userTypeChoice.getSelectionModel().clearSelection();
    }

    public void setSceneChanger(SceneChanger sceneChanger) {
        this.sceneChanger = sceneChanger;
    }
}
