package com.example.sdapp;

import com.example.dao.*;
import com.example.models.*;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;

import java.sql.SQLException;
import java.util.Date;
import java.util.List;

public class LandingPageController {

    @FXML
    private Label welcomeLabel;

    @FXML
    private Label userDetailsLabel;

    @FXML
    private TabPane tabPane;

    // Tabs
    @FXML
    private Tab manageRoomTab;

    @FXML
    private Tab manageRestaurantTab;

    @FXML
    private Tab manageHallTab;

    @FXML
    private Tab manageRoomServiceTab;

    @FXML
    private Tab manageGuestsTab;

    @FXML
    private Tab manageStaffTab;

    private User currentUser;
    private SceneChanger sceneChanger;

    @FXML
    private TableView<Room> roomTable;

    @FXML
    private TableColumn<Room, Integer> roomIdColumn;

    @FXML
    private TableColumn<Room, String> roomTypeColumn;

    @FXML
    private TableColumn<Room, String> roomAvailabilityColumn;

    @FXML
    private Button bookRoomButton;

    @FXML
    private Label statusLabel;

    private ObservableList<Room> roomData = FXCollections.observableArrayList();

    @FXML
    private TableView<Hall> hallTable;
    @FXML
    private TableColumn<Hall, Integer> hallIdColumn;
    @FXML
    private TableColumn<Hall, Integer> hallCapacityColumn;

    @FXML
    private TableView<TimeSlot> timeSlotTable2;
    @FXML
    private TableColumn<TimeSlot, String> timeSlotRangeColumn2;
    @FXML
    private TableColumn<TimeSlot, String> timeSlotAvailabilityColumn2;

    @FXML
    private Button bookTimeSlotButton2;
    @FXML
    private Label timeSlotStatusLabel2;

    private ObservableList<Hall> hallData = FXCollections.observableArrayList();

    @FXML
    private TableView<Table> restaurantTableView;
    @FXML
    private TableColumn<Table, Integer> tableIdColumn;

    @FXML
    private TableView<TimeSlot> timeSlotTableView;
    @FXML
    private TableColumn<TimeSlot, String> timeSlotRangeColumn;
    @FXML
    private TableColumn<TimeSlot, String> timeSlotAvailabilityColumn;

    @FXML
    private Button bookTimeSlotButton;
    @FXML
    private Label restaurantStatusLabel;

    private ObservableList<Table> tableData = FXCollections.observableArrayList();
    private ObservableList<TimeSlot> timeSlotData = FXCollections.observableArrayList();

    private ObservableList<Restaurant> restaurantData = FXCollections.observableArrayList();

    @FXML
    private TableView<ServiceRequest> roomServiceTable;
    @FXML
    private TableColumn<ServiceRequest, Integer> serviceRequestIdColumn;
    @FXML
    private TableColumn<ServiceRequest, Integer> serviceRoomIdColumn;
    @FXML
    private TableColumn<ServiceRequest, String> serviceDescriptionColumn;
    @FXML
    private TableColumn<ServiceRequest, String> serviceStatusColumn;

    @FXML
    private Button resolveRoomServiceButton;
    @FXML
    private Label roomServiceStatusLabel;

    private ObservableList<ServiceRequest> roomServiceData = FXCollections.observableArrayList();

    @FXML
    private TableView<User> guestTable;
    @FXML
    private TableColumn<User, Integer> guestIdColumn;
    @FXML
    private TableColumn<User, String> guestNameColumn;
    @FXML
    private TableColumn<User, String> guestEmailColumn;
    @FXML
    private TableColumn<User, String> guestContactColumn;

    @FXML
    private TextField guestNameField;
    @FXML
    private TextField guestEmailField;
    @FXML
    private TextField guestContactField;
    @FXML
    private TextField guestAddressField;

    @FXML
    private Button addGuestButton;
    @FXML
    private Button updateGuestButton;
    @FXML
    private Button deleteGuestButton;
    @FXML
    private Label guestStatusLabel;

    private ObservableList<User> guestData = FXCollections.observableArrayList();

    @FXML
    private TableView<User> staffTable;
    @FXML
    private TableColumn<User, Integer> staffIdColumn;
    @FXML
    private TableColumn<User, String> staffNameColumn;
    @FXML
    private TableColumn<User, String> staffEmailColumn;
    @FXML
    private TableColumn<User, String> staffContactColumn;

    @FXML
    private TextField staffNameField;
    @FXML
    private TextField staffEmailField;
    @FXML
    private TextField staffContactField;
    @FXML
    private TextField staffAddressField;

    @FXML
    private Button addStaffButton;
    @FXML
    private Button updateStaffButton;
    @FXML
    private Button deleteStaffButton;
    @FXML
    private Label staffStatusLabel;

    private ObservableList<User> staffData = FXCollections.observableArrayList();

    // Room Tab
    @FXML private TableView<Room> roomTableView;
    @FXML private TableColumn<Room, Integer> roomCapacityColumn;
    @FXML private DatePicker roomBookingStartDate;
    @FXML private DatePicker roomBookingEndDate;
    @FXML private Label roomBookingStatusLabel;

    // Restaurant Tab
    @FXML private TableColumn<Table, Integer> restaurantTableIdColumn;
    @FXML private TableColumn<Table, Integer> restaurantCapacityColumn;
    @FXML private TableView<TimeSlot> restaurantTimeSlotTable;
    @FXML private TableColumn<TimeSlot, String> restaurantTimeSlotRangeColumn;
    @FXML private TableColumn<TimeSlot, String> restaurantTimeSlotAvailabilityColumn;

    // Hall Tab
    @FXML private TableView<Hall> hallTableView;
    @FXML private TableView<TimeSlot> hallTimeSlotTable;
    @FXML private TableColumn<TimeSlot, String> hallTimeSlotRangeColumn;
    @FXML private TableColumn<TimeSlot, String> hallTimeSlotAvailabilityColumn;
    @FXML private Button bookHallTimeSlotButton;
    @FXML private Label hallStatusLabel;

    private ObservableList<Table> restaurantTableData = FXCollections.observableArrayList();
    private ObservableList<TimeSlot> restaurantTimeSlotData = FXCollections.observableArrayList();
    private ObservableList<TimeSlot> hallTimeSlotData = FXCollections.observableArrayList();

    @FXML
    private VBox paymentMethodBox;
    @FXML
    private RadioButton cardOption;
    @FXML
    private RadioButton bankTransferOption;
    @FXML
    private ToggleGroup paymentToggleGroup;

    @FXML
    private Label paymentDetailLabel;
    @FXML
    private TextField paymentDetailField;
    @FXML
    private Label totalPriceLabel;
    @FXML
    private Button submitPaymentButton;
    @FXML
    private Label paymentStatusLabel;

    private double totalPrice = 0.0;

    public void initializePaymentTab(int userId) {
        // Add listeners to toggle group to update the payment detail label
        paymentToggleGroup.selectedToggleProperty().addListener((obs, oldToggle, newToggle) -> {
            if (newToggle == cardOption) {
                paymentDetailLabel.setText("Card Number");
            } else if (newToggle == bankTransferOption) {
                paymentDetailLabel.setText("Account Number");
            }
        });

        try {
            calculateTotalPrice(userId);
        } catch (SQLException e) {
            paymentStatusLabel.setText("Error calculating total price.");
            e.printStackTrace();
        }
    }

    private void calculateTotalPrice(int userId) throws SQLException {
        ReservationDAO reservationDAO = new ReservationDAO();
        RoomDAO roomDAO = new RoomDAO();
        RestaurantDAO restaurantDAO = new RestaurantDAO();
        HallDAO hallDAO = new HallDAO();

        List<Reservation> reservations = reservationDAO.getReservationsByUser(userId);
        totalPrice = 0.0;

        for (Reservation res : reservations) {
            if (res instanceof RoomReservation) {
                RoomReservation rr = (RoomReservation) res;
                double roomPrice = roomDAO.getRoomPrice(rr.getRoomId());
                long days = (rr.getEndDate().getTime() - rr.getStartDate().getTime()) / (1000 * 60 * 60 * 24);
                totalPrice += roomPrice * days;
            } else if (res instanceof RestaurantReservation) {
                totalPrice += 60; // Restaurant reservations cost $60 flat rate
            } else if (res instanceof HallReservation) {
                HallReservation hr = (HallReservation) res;
                double hallPrice = hallDAO.getHallPrice(hr.getHallId());
                totalPrice += hallPrice;
            }
        }

        totalPriceLabel.setText("$" + String.format("%.2f", totalPrice));
    }

    @FXML
    private void onSubmitPaymentPressed() {
        String paymentMethod;
        if(cardOption.isSelected() && cardOption.isSelected()){
            paymentStatusLabel.setText("Please select one payment method.");
            return;
        } else if (cardOption.isSelected()) {
            paymentMethod = "Card";
        } else if (bankTransferOption.isSelected()) {
            paymentMethod = "Bank Transfer";
        } else {
            paymentStatusLabel.setText("Please select a payment method.");
            return;
        }

        String paymentDetail = paymentDetailField.getText();

        if (paymentDetail.isEmpty()) {
            paymentStatusLabel.setText("Please enter payment details.");
            return;
        }

        PaymentStrategy paymentStrategy;
        if ("Card".equals(paymentMethod)) {
            paymentStrategy = new CardPayment();
        } else {
            paymentStrategy = new BankTransferPayment();
        }

        if (paymentStrategy.processPayment(paymentDetail, totalPrice)) {
            paymentStatusLabel.setText("Payment successful. Thank you!");
        } else {
            paymentStatusLabel.setText("Payment failed. Please try again.");
        }
    }



    public void initialize() {
        initializeRoomTab();
        initializeRestaurantTab();
        initializeHallTab();
    }

    private void initializeRoomTab() {
        roomIdColumn.setCellValueFactory(new PropertyValueFactory<>("roomId"));
        roomTypeColumn.setCellValueFactory(new PropertyValueFactory<>("roomType"));
        roomCapacityColumn.setCellValueFactory(new PropertyValueFactory<>("capacity"));

        try {
            RoomDAO roomDAO = new RoomDAO();
            roomData.addAll(roomDAO.getAllRooms());
        } catch (SQLException e) {
            roomBookingStatusLabel.setText("Error loading rooms.");
            e.printStackTrace();
        }

        roomTableView.setItems(roomData);
    }

    @FXML
    private void onBookRoomPressed() {
        Room selectedRoom = roomTableView.getSelectionModel().getSelectedItem();
        Date startDate = java.sql.Date.valueOf(roomBookingStartDate.getValue());
        Date endDate = java.sql.Date.valueOf(roomBookingEndDate.getValue());

        if (selectedRoom == null || startDate == null || endDate == null) {
            roomBookingStatusLabel.setText("Please select a room and specify dates.");
            return;
        }

        RoomReservation reservation = new RoomReservation(0, 1, selectedRoom.getRoomId(), startDate, endDate);

        try {
            ReservationDAO reservationDAO = new ReservationDAO();
            if (reservationDAO.addReservation(reservation)) {
                roomBookingStatusLabel.setText("Room booked successfully!");
            } else {
                roomBookingStatusLabel.setText("Failed to book room.");
            }
        } catch (SQLException e) {
            roomBookingStatusLabel.setText("Database error occurred.");
            e.printStackTrace();
        }
    }

    private void initializeRestaurantTab() {
        restaurantTableIdColumn.setCellValueFactory(new PropertyValueFactory<>("tableId"));
        restaurantCapacityColumn.setCellValueFactory(new PropertyValueFactory<>("capacity"));

        restaurantTimeSlotRangeColumn.setCellValueFactory(new PropertyValueFactory<>("timeRange"));
        restaurantTimeSlotAvailabilityColumn.setCellValueFactory(new PropertyValueFactory<>("availabilityString"));

        try {
            RestaurantDAO restaurantDAO = new RestaurantDAO();
            Restaurant restaurant = restaurantDAO.getRestaurant();

            if (restaurant != null) {
                restaurantTableData.addAll(restaurant.getTables());
            } else {
                restaurantStatusLabel.setText("No tables found for this restaurant.");
            }
        } catch (SQLException e) {
            restaurantStatusLabel.setText("Error loading tables.");
            e.printStackTrace();
        }

        restaurantTableView.setItems(restaurantTableData);

        restaurantTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                restaurantTimeSlotData.clear();
                restaurantTimeSlotData.addAll(newSelection.getTimeSlots());
                restaurantTimeSlotTable.setItems(restaurantTimeSlotData);
            }
        });
    }

    @FXML
    private void onBookRestaurantTimeSlotPressed() {
        TimeSlot selectedSlot = restaurantTimeSlotTable.getSelectionModel().getSelectedItem();

        if (selectedSlot == null) {
            restaurantStatusLabel.setText("Please select a time slot to book.");
            return;
        }

        try {
            RestaurantReservation reservation = new RestaurantReservation(0, 1, 1, restaurantTableView.getSelectionModel().getSelectedItem().getTableId(), selectedSlot.getSlotId(), new Date(), new Date());
            ReservationDAO reservationDAO = new ReservationDAO();
            if (reservationDAO.addReservation(reservation)) {
                selectedSlot.setAvailable(false);
                restaurantTimeSlotTable.refresh();
                restaurantStatusLabel.setText("Time slot booked successfully!");
            } else {
                restaurantStatusLabel.setText("Failed to book time slot.");
            }
        } catch (SQLException e) {
            restaurantStatusLabel.setText("Database error occurred.");
            e.printStackTrace();
        }
    }

    private void initializeHallTab() {
        hallIdColumn.setCellValueFactory(new PropertyValueFactory<>("hallId"));
        hallCapacityColumn.setCellValueFactory(new PropertyValueFactory<>("capacity"));

        hallTimeSlotRangeColumn.setCellValueFactory(new PropertyValueFactory<>("timeRange"));
        hallTimeSlotAvailabilityColumn.setCellValueFactory(new PropertyValueFactory<>("availabilityString"));

        try {
            HallDAO hallDAO = new HallDAO();
            hallData.addAll(hallDAO.getAllHalls());
        } catch (SQLException e) {
            hallStatusLabel.setText("Error loading halls.");
            e.printStackTrace();
        }

        hallTableView.setItems(hallData);

        hallTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                hallTimeSlotData.clear();
                hallTimeSlotData.addAll(newSelection.getTimeSlots());
                hallTimeSlotTable.setItems(hallTimeSlotData);
            }
        });
    }

    @FXML
    private void onBookHallTimeSlotPressed() {
        TimeSlot selectedSlot = hallTimeSlotTable.getSelectionModel().getSelectedItem();

        if (selectedSlot == null) {
            hallStatusLabel.setText("Please select a time slot to book.");
            return;
        }

        try {
            HallReservation reservation = new HallReservation(0, 1, hallTable.getSelectionModel().getSelectedItem().getHallId(), selectedSlot.getSlotId(), new Date(), new Date());
            ReservationDAO reservationDAO = new ReservationDAO();
            if (reservationDAO.addReservation(reservation)) {
                selectedSlot.setAvailable(false);
                hallTimeSlotTable.refresh();
                hallStatusLabel.setText("Time slot booked successfully!");
            } else {
                hallStatusLabel.setText("Failed to book time slot.");
            }
        } catch (SQLException e) {
            hallStatusLabel.setText("Database error occurred.");
            e.printStackTrace();
        }
    }


    private void initializeStaffTab() {
        staffIdColumn.setCellValueFactory(new PropertyValueFactory<>("userID"));
        staffNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        staffEmailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        staffContactColumn.setCellValueFactory(new PropertyValueFactory<>("contactInfo"));

        try {
            UserDAO userDAO = new UserDAO();
            staffData.addAll(userDAO.getAllUsers().stream().filter(u -> u.getRole().equalsIgnoreCase("employee")).toList());
        } catch (SQLException e) {
            staffStatusLabel.setText("Error loading staff.");
            e.printStackTrace();
        }

        staffTable.setItems(staffData);

        staffTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                staffNameField.setText(newSelection.getName());
                staffEmailField.setText(newSelection.getEmail());
                staffContactField.setText(newSelection.getcontactInfo());
                staffAddressField.setText(newSelection.getAddress());
            }
        });
    }

    @FXML
    private void onAddStaffPressed() {
        String name = staffNameField.getText();
        String email = staffEmailField.getText();
        String contactInfo = staffContactField.getText();
        String address = staffAddressField.getText();

        if (name.isEmpty() || email.isEmpty() || contactInfo.isEmpty() || address.isEmpty()) {
            staffStatusLabel.setText("Please fill in all fields.");
            return;
        }

        Employee newStaff = new Employee(0, name, "", "employee", email, name, contactInfo, address);

        try {
            UserDAO userDAO = new UserDAO();
            if (userDAO.addUser(newStaff)) {
                staffData.add(newStaff);
                staffStatusLabel.setText("Staff added successfully!");
                clearStaffForm();
            } else {
                staffStatusLabel.setText("Failed to add staff.");
            }
        } catch (SQLException e) {
            staffStatusLabel.setText("Database error occurred.");
            e.printStackTrace();
        }
    }

    @FXML
    private void onUpdateStaffPressed() {
        User selectedStaff = staffTable.getSelectionModel().getSelectedItem();

        if (selectedStaff == null) {
            staffStatusLabel.setText("Please select a staff member to update.");
            return;
        }

        selectedStaff.setName(staffNameField.getText());
        selectedStaff.setEmail(staffEmailField.getText());
        selectedStaff.setContactInfo(staffContactField.getText());
        selectedStaff.setAddress(staffAddressField.getText());

        try {
            UserDAO userDAO = new UserDAO();
            if (userDAO.updateUser(selectedStaff)) {
                staffTable.refresh();
                staffStatusLabel.setText("Staff updated successfully!");
            } else {
                staffStatusLabel.setText("Failed to update staff.");
            }
        } catch (SQLException e) {
            staffStatusLabel.setText("Database error occurred.");
            e.printStackTrace();
        }
    }

    @FXML
    private void onDeleteStaffPressed() {
        User selectedStaff = staffTable.getSelectionModel().getSelectedItem();

        if (selectedStaff == null) {
            staffStatusLabel.setText("Please select a staff member to delete.");
            return;
        }

        try {
            UserDAO userDAO = new UserDAO();
            if (userDAO.deleteUser(selectedStaff.getUserID())) {
                staffData.remove(selectedStaff);
                staffStatusLabel.setText("Staff deleted successfully!");
                clearStaffForm();
            } else {
                staffStatusLabel.setText("Failed to delete staff.");
            }
        } catch (SQLException e) {
            staffStatusLabel.setText("Database error occurred.");
            e.printStackTrace();
        }
    }

    private void clearStaffForm() {
        staffNameField.clear();
        staffEmailField.clear();
        staffContactField.clear();
        staffAddressField.clear();
    }



    private void initializeGuestsTab() {
        guestIdColumn.setCellValueFactory(new PropertyValueFactory<>("userID"));
        guestNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        guestEmailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        guestContactColumn.setCellValueFactory(new PropertyValueFactory<>("contactInfo"));

        try {
            UserDAO userDAO = new UserDAO();
            guestData.addAll(userDAO.getAllUsers().stream().filter(u -> u.getRole().equalsIgnoreCase("guest")).toList());
        } catch (SQLException e) {
            guestStatusLabel.setText("Error loading guests.");
            e.printStackTrace();
        }

        guestTable.setItems(guestData);

        guestTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                guestNameField.setText(newSelection.getName());
                guestEmailField.setText(newSelection.getEmail());
                guestContactField.setText(newSelection.getcontactInfo());
                guestAddressField.setText(newSelection.getAddress());
            }
        });
    }

    @FXML
    private void onAddGuestPressed() {
        String name = guestNameField.getText();
        String email = guestEmailField.getText();
        String contactInfo = guestContactField.getText();
        String address = guestAddressField.getText();

        if (name.isEmpty() || email.isEmpty() || contactInfo.isEmpty() || address.isEmpty()) {
            guestStatusLabel.setText("Please fill in all fields.");
            return;
        }

        Guest newGuest = new Guest(0, name, "", email, name, contactInfo, address,name);

        try {
            UserDAO userDAO = new UserDAO();
            if (userDAO.addUser(newGuest)) {
                guestData.add(newGuest);
                guestStatusLabel.setText("Guest added successfully!");
                clearGuestForm();
            } else {
                guestStatusLabel.setText("Failed to add guest.");
            }
        } catch (SQLException e) {
            guestStatusLabel.setText("Database error occurred.");
            e.printStackTrace();
        }
    }

    @FXML
    private void onUpdateGuestPressed() {
        User selectedGuest = guestTable.getSelectionModel().getSelectedItem();

        if (selectedGuest == null) {
            guestStatusLabel.setText("Please select a guest to update.");
            return;
        }

        selectedGuest.setName(guestNameField.getText());
        selectedGuest.setEmail(guestEmailField.getText());
        selectedGuest.setContactInfo(guestContactField.getText());
        selectedGuest.setAddress(guestAddressField.getText());

        try {
            UserDAO userDAO = new UserDAO();
            if (userDAO.updateUser(selectedGuest)) {
                guestTable.refresh();
                guestStatusLabel.setText("Guest updated successfully!");
            } else {
                guestStatusLabel.setText("Failed to update guest.");
            }
        } catch (SQLException e) {
            guestStatusLabel.setText("Database error occurred.");
            e.printStackTrace();
        }
    }

    @FXML
    private void onDeleteGuestPressed() {
        User selectedGuest = guestTable.getSelectionModel().getSelectedItem();

        if (selectedGuest == null) {
            guestStatusLabel.setText("Please select a guest to delete.");
            return;
        }

        try {
            UserDAO userDAO = new UserDAO();
            if (userDAO.deleteUser(selectedGuest.getUserID())) {
                guestData.remove(selectedGuest);
                guestStatusLabel.setText("Guest deleted successfully!");
                clearGuestForm();
            } else {
                guestStatusLabel.setText("Failed to delete guest.");
            }
        } catch (SQLException e) {
            guestStatusLabel.setText("Database error occurred.");
            e.printStackTrace();
        }
    }

    private void clearGuestForm() {
        guestNameField.clear();
        guestEmailField.clear();
        guestContactField.clear();
        guestAddressField.clear();
    }


    private void initializeRoomServiceTab() {
        // Set up table columns
        serviceRequestIdColumn.setCellValueFactory(new PropertyValueFactory<>("serviceId"));
        serviceRoomIdColumn.setCellValueFactory(new PropertyValueFactory<>("roomId"));
        serviceDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        serviceStatusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        try {
            // Load room service requests from the database
            ServiceRequestDAO serviceRequestDAO = new ServiceRequestDAO();
            roomServiceData.addAll(serviceRequestDAO.getAllPendingRequests());
        } catch (SQLException e) {
            roomServiceStatusLabel.setText("Error loading room service requests.");
            e.printStackTrace();
        }

        roomServiceTable.setItems(roomServiceData);
    }

    @FXML
    private void onResolveRoomServicePressed() {
        ServiceRequest selectedRequest = roomServiceTable.getSelectionModel().getSelectedItem();

        if (selectedRequest == null) {
            roomServiceStatusLabel.setText("Please select a request to resolve.");
            return;
        }

        try {
            ServiceRequestDAO serviceRequestDAO = new ServiceRequestDAO();
            if (serviceRequestDAO.resolveRequest(selectedRequest.getServiceId())) {
                roomServiceData.remove(selectedRequest);
                roomServiceStatusLabel.setText("Request resolved successfully!");
            } else {
                roomServiceStatusLabel.setText("Failed to resolve request.");
            }
        } catch (SQLException e) {
            roomServiceStatusLabel.setText("Database error occurred.");
            e.printStackTrace();
        }
    }

    @FXML
    private void onBookTimeSlotPressed2() {
        TimeSlot selectedSlot = timeSlotTable2.getSelectionModel().getSelectedItem();

        if (selectedSlot == null) {
            timeSlotStatusLabel2.setText("Please select a time slot to book.");
            return;
        }

        try {
            HallDAO hallDAO = new HallDAO();
            if (hallDAO.bookHallTimeSlot(selectedSlot.getSlotId())) {
                selectedSlot.setAvailable(false);
                timeSlotTable2.refresh();
                timeSlotStatusLabel2.setText("Time slot booked successfully!");
            } else {
                timeSlotStatusLabel2.setText("Failed to book time slot.");
            }
        } catch (SQLException e) {
            timeSlotStatusLabel2.setText("Database error occurred.");
            e.printStackTrace();
        }
    }

    @FXML
    private void onBookTimeSlotPressed() {
        TimeSlot selectedTimeSlot = timeSlotTableView.getSelectionModel().getSelectedItem();

        if (selectedTimeSlot == null) {
            restaurantStatusLabel.setText("Please select a time slot to book.");
            return;
        }

        try {
            // Book the selected time slot
            RestaurantDAO restaurantDAO = new RestaurantDAO();
            if (restaurantDAO.bookTimeSlot(selectedTimeSlot.getSlotId())) {
                selectedTimeSlot.setAvailable(false);
                timeSlotTableView.refresh();
                restaurantStatusLabel.setText("Time slot booked successfully!");
            } else {
                restaurantStatusLabel.setText("Failed to book time slot.");
            }
        } catch (SQLException e) {
            restaurantStatusLabel.setText("Database error occurred.");
            e.printStackTrace();
        }
    }

    public void initializePage(User user) {
        this.currentUser = user;

        // Set welcome message and user details
        welcomeLabel.setText("Welcome, " + user.getName());
        userDetailsLabel.setText("Role: " + user.getRole());

        // Adjust tab visibility based on role
        configureTabsByRole(user.getRole());
    }

    /**
     * Configures tab visibility and functionality based on the user's role.
     *
     * @param role The user's role (Guest, Employee, Admin).
     */
    private void configureTabsByRole(String role) {
        switch (role.toLowerCase()) {
            case "guest":
                manageRoomServiceTab.setDisable(true); // Disabled unless room is reserved
                manageGuestsTab.setDisable(true);
                manageStaffTab.setDisable(true);
                break;

            case "employee":
                manageRoomServiceTab.setDisable(false);
                manageGuestsTab.setDisable(false);
                manageStaffTab.setDisable(true);
                break;

            case "admin":
                manageRoomServiceTab.setDisable(false);
                manageGuestsTab.setDisable(false);
                manageStaffTab.setDisable(false);
                break;

            default:
                // If the role is unknown, disable all tabs
                tabPane.getTabs().forEach(tab -> tab.setDisable(true));
        }
    }

    /**
     * Enables the "Request Room Service" tab if a room is reserved by the guest.
     */
    public void enableRoomServiceTabForGuest() {
        if (currentUser.getRole().equalsIgnoreCase("guest")) {
            manageRoomServiceTab.setDisable(false);
        }
    }

    public void setSceneChanger(SceneChanger sceneChanger) {
        this.sceneChanger = sceneChanger;
    }
}
