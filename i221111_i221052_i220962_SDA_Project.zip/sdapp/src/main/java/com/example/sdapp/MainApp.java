package com.example.sdapp;

import com.example.db.DBHandler;
import javafx.application.Application;
import javafx.stage.Stage;

import java.io.IOException;

public class MainApp extends Application {

    SceneChanger sceneChanger = new SceneChanger();
    DBHandler dbHandler = DBHandler.getInstance();

    @Override
    public void start(Stage stage) throws IOException {
        sceneChanger.changeScene("hello-view.fxml","Hotelify - Welcome !",600,400);
    }

    public static void main(String[] args) {
        launch();
    }
}