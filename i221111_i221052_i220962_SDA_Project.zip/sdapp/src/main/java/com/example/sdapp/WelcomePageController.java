package com.example.sdapp;

import com.example.dao.UserDAO;
import com.example.models.User;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.sql.SQLException;

public class WelcomePageController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label errorLabel;

    private SceneChanger sceneChanger;

    // Set SceneChanger instance
    public void setSceneChanger(SceneChanger sceneChanger) {
        this.sceneChanger = sceneChanger;
    }

    @FXML
    private void onLoginPressed() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        // Validate input
        if (username.isEmpty() || password.isEmpty()) {
            errorLabel.setText("Please fill in all fields.");
            return;
        }

        try {
            // Check user authentication
            UserDAO userDAO = new UserDAO();
            User user = authenticateUser(userDAO, username, password);

            if (user != null) {
                // Navigate to Landing Page with user details
                sceneChanger.changeScene(
                        "/fxml/LandingPage.fxml",
                        "Hotelify - Dashboard",
                        1200,
                        600
                );
            } else {
                errorLabel.setText("Invalid username or password.");
            }

        } catch (SQLException e) {
            errorLabel.setText("Database error occurred. Please try again later.");
            e.printStackTrace();
        } catch (Exception e) {
            errorLabel.setText("An unexpected error occurred.");
            e.printStackTrace();
        }
    }

    /**
     * Authenticates the user by checking the database for matching credentials.
     *
     * @param userDAO  DAO to query the user data.
     * @param username Username to authenticate.
     * @param password Password to authenticate.
     * @return Authenticated User instance or null if authentication fails.
     * @throws SQLException in case of database issues.
     */
    private User authenticateUser(UserDAO userDAO, String username, String password) throws SQLException {
        for (User user : userDAO.getAllUsers()) {
            // In a real application, passwords should be hashed and compared securely
            if (user.getName().equals(username) && password.equals("password")) { // Simplified for demo
                return user;
            }
        }
        return null;
    }

    @FXML
    private void onRegisterPressed() {
        try {
            sceneChanger.changeScene("register-page.fxml", "Hotelify - Register", 600, 600);
        } catch (Exception e) {
            errorLabel.setText("Failed to load the register page.");
            e.printStackTrace();
        }
    }
}
