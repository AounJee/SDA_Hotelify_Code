module com.example.sdapp {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.sdapp to javafx.fxml;
    exports com.example.sdapp;
    exports com.example.models;
    opens com.example.models to javafx.fxml;
    exports com.example.db;
    opens com.example.db to javafx.fxml;
    exports com.example.dao;
    opens com.example.dao to javafx.fxml;
}